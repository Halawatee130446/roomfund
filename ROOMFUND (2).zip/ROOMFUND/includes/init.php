<?php
session_start();
require_once __DIR__ . '/config.php';
require_once ROOT_PATH . '/includes/db.php';
require_once ROOT_PATH . '/includes/functions.php';
?>