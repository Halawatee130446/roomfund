<?php
// config.php
define('ROOT_PATH', __DIR__ . '/..');
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'roomfund');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASE_URL', '/ROOMFUND');
define('UPLOAD_DIR', ROOT_PATH . '/uploads/');